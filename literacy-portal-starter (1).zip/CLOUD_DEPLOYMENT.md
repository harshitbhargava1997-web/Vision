# Cloud Deployment Actions

This project is prepared for a separate cloud deployment on Vercel with Supabase Auth and Supabase Postgres.

## 1. Create GitHub repository

Repository name:

```text
Vision
```

Upload the contents of this folder to that repository.

Do not upload:

```text
node_modules
.next
.env.local
```

## 2. Import into Vercel

In Vercel:

1. Create a new project.
2. Import the GitHub repository.
3. Keep framework as Next.js.
4. Keep root directory as the repository root if this folder is uploaded directly.
5. Use `npm ci` for install and `npm run build` for build.

## 3. Add environment variables

Add these to Production, Preview, and Development:

```env
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=
```

Use the Supabase publishable key. Do not use the service role key in any `NEXT_PUBLIC_` variable.

## 4. Configure Supabase Auth

In Supabase Auth URL configuration, add:

```text
https://your-vercel-project.vercel.app/**
```

After adding a custom domain, also add:

```text
https://yourdomain.com/**
```

## 5. Verify deployment

Check these routes:

```text
/api/health
/login
/dashboard
```

Expected flow:

1. `/api/health` returns a JSON response.
2. `/login` opens publicly.
3. Valid Supabase user can sign in.
4. Signed-in user reaches `/dashboard`.
5. Sign out returns the user to `/login`.

## 6. Next product module

After deployment is working, build the Nursery assessment module:

- A to Z letter recognition
- phonetic sound identification
- action identification
- action to letter selection
- sound to letter selection
- initial sound identification
- missing letter report
- assessor role capture: principal, coordinator, academic consultant
- teacher readiness report
