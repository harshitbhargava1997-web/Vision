import { NextResponse } from "next/server";

export function GET() {
  return NextResponse.json({
    ok: true,
    app: "literacy-portal",
    service: "foundational-literacy",
  });
}
