import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Literacy Portal | Literacy learning",
  description: "Foundational reading and writing assessment for schools.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
