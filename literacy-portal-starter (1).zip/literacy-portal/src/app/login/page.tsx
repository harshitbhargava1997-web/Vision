import Link from "next/link";
import { signIn } from "@/app/actions";

const messages: Record<string, string> = {
  missing: "Enter your email and password to continue.",
  credentials: "We could not sign you in with those details.",
};

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const { error } = await searchParams;

  return (
    <main className="login-screen">
      <section className="login-brand">
        <Link className="brand" href="/" aria-label="Literacy Portal home">
          <span className="brand-mark">S</span><span>Literacy Portal</span>
        </Link>
        <div className="brand-message">
          <span className="eyebrow light">READING · WRITING · GROWTH</span>
          <h1>Every small sound leads to a bigger story.</h1>
          <p>A shared space for teachers and school leaders to strengthen foundational literacy.</p>
          <div className="letter-row" aria-hidden="true"><i>A</i><i>b</i><i>m</i><i>sh</i><i>★</i></div>
        </div>
        <span className="brand-footnote">Nursery to Grade 2 · Foundational literacy</span>
      </section>

      <section className="login-panel">
        <div className="login-card">
          <span className="eyebrow">SCHOOL PORTAL</span>
          <h2>Welcome back</h2>
          <p className="muted">Sign in with your school account to continue.</p>
          {error && messages[error] && <p className="form-error" role="alert">{messages[error]}</p>}
          <form action={signIn} className="login-form">
            <label htmlFor="email">Email address</label>
            <input id="email" name="email" type="email" autoComplete="username" placeholder="you@school.org" required />
            <label htmlFor="password">Password</label>
            <input id="password" name="password" type="password" autoComplete="current-password" placeholder="Enter your password" required />
            <button className="button button-primary login-button" type="submit">Sign in <span aria-hidden="true">→</span></button>
          </form>
          <p className="login-help">Your school administrator can help with account access.</p>
        </div>
        <span className="login-copyright">A calm, clear view of learning progress.</span>
      </section>
    </main>
  );
}
