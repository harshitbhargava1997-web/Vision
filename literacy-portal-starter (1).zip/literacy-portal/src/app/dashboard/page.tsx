import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { signOut } from "@/app/actions";

const stages = ["Nursery", "LKG", "UKG", "Grade 1", "Grade 2"];

export default async function DashboardPage() {
  const supabase = await createClient();
  const { data, error } = await supabase.auth.getClaims();
  if (error || !data?.claims) redirect("/login");

  const email = typeof data.claims.email === "string" ? data.claims.email : "School team";

  return (
    <main className="app-shell">
      <aside className="sidebar">
        <a href="/dashboard" className="brand"><span className="brand-mark">S</span><span>Literacy Portal</span></a>
        <div className="school-switcher"><span className="school-avatar">S</span><span><b>Your school</b><small>Literacy workspace</small></span><span className="switch-chevron">⌄</span></div>
        <span className="nav-label">WORKSPACE</span>
        <nav className="side-nav" aria-label="Main navigation">
          <a className="nav-item active" href="/dashboard"><span>▦</span> Overview</a>
          <a className="nav-item disabled" href="#teachers"><span>♙</span> Teachers <small>Next</small></a>
          <a className="nav-item disabled" href="#students"><span>◉</span> Students <small>Next</small></a>
          <a className="nav-item disabled" href="#reports"><span>▤</span> Reports <small>Next</small></a>
        </nav>
        <div className="sidebar-bottom"><div className="help-card"><span className="help-icon">✳</span><b>Building literacy, together</b><p>Teacher learning and student progress in one place.</p></div><div className="user-row"><span className="user-avatar">{email[0]?.toUpperCase() ?? "S"}</span><span className="user-meta"><b>{email}</b><small>Signed in</small></span><form action={signOut}><button className="icon-button" aria-label="Sign out" title="Sign out">↗</button></form></div></div>
      </aside>

      <section className="main-content">
        <header className="topbar"><div className="breadcrumbs">Workspace <span>/</span> <b>Overview</b></div><div className="topbar-right"><span className="status-dot"/> Pilot workspace <span className="topbar-divider"/><span className="user-avatar small">{email[0]?.toUpperCase() ?? "S"}</span></div></header>
        <div className="page-wrap">
          <div className="welcome-row"><div><span className="eyebrow">SCHOOL LEADER VIEW</span><h1>Good morning <span className="wave">✳</span></h1><p className="muted">A starting point for building a strong literacy practice across your school.</p></div><div className="date-pill">Foundational literacy <span>·</span> Nursery–Grade 2</div></div>

          <section className="hero-card"><div className="hero-copy"><span className="hero-tag">YOUR LITERACY JOURNEY</span><h2>See what teachers know.<br/><em>Support what children learn.</em></h2><p>Begin with teacher readiness, then follow the classroom learning journey from letter sounds to confident reading and writing.</p><a className="hero-link" href="#getting-started">Explore the workspace <span>→</span></a></div><div className="hero-art" aria-hidden="true"><span className="sun"/><span className="orbit orbit-one"/><span className="orbit orbit-two"/><span className="orbit-letter letter-a">A</span><span className="orbit-letter letter-sh">sh</span><span className="orbit-letter letter-m">m</span><span className="book book-one"/><span className="book book-two"/><span className="book book-three"/></div></section>

          <section className="section-block" id="getting-started"><div className="section-heading"><div><span className="eyebrow">START HERE</span><h2>Two connected learning journeys</h2></div><span className="section-note">Teacher readiness comes first</span></div><div className="journey-grid"><article className="journey-card teacher-card"><div className="card-icon teacher-icon">♙</div><div className="card-heading"><div><span className="card-kicker">01 · TEACHER</span><h3>Teacher readiness</h3></div><span className="status-tag">Coming next</span></div><p>Review a teacher’s understanding of the literacy competencies and identify the next coaching step.</p><div className="card-footer"><span>Assessor → Teacher</span><span className="arrow">→</span></div></article><article className="journey-card student-card"><div className="card-icon student-icon">✎</div><div className="card-heading"><div><span className="card-kicker">02 · STUDENT</span><h3>Student progress</h3></div><span className="status-tag">Coming next</span></div><p>Track classroom learning from sound–symbol knowledge to words, sentences, and early writing.</p><div className="card-footer"><span>Teacher → Class → Student</span><span className="arrow">→</span></div></article></div></section>

          <section className="section-block progression-block"><div className="section-heading"><div><span className="eyebrow">VERTICAL PROGRESSION</span><h2>One literacy pathway, five stages</h2></div><span className="section-note">Reading and writing focus</span></div><div className="stage-track">{stages.map((stage, index) => <div className="stage" key={stage}><span className={`stage-dot ${index === 0 ? "stage-current" : ""}`}>{index === 0 ? "✓" : String(index + 1).padStart(2, "0")}</span><b>{stage}</b><span>{index === 0 ? "Sounds & symbols" : index === 1 ? "VC · CVC · sentences" : index === 2 ? "Digraphs · blends" : index === 3 ? "Syllables · dictation" : "Fluency · composition"}</span></div>)}</div></section>

          <section className="next-step"><span className="next-step-icon">↗</span><div><b>Your workspace is ready to be connected</b><p>Next: connect the school roster and agree the role and access rules before real assessments are enabled.</p></div><span className="next-step-badge">SETUP</span></section>
          <footer className="page-footer"><span>Literacy Portal · Foundational literacy</span><span>Teacher growth and student learning, connected.</span></footer>
        </div>
      </section>
    </main>
  );
}
